print('hi , this is first program ')
print("we are learning python core")

